Write-Host '=== OverlineEdge v8 ===' -ForegroundColor Cyan
Write-Host 'No Docker. No compiler. No API keys.' -ForegroundColor Green
Set-Location "$PSScriptRoot\backend"
Write-Host '[1/3] Installing deps (Python 3.14 compatible)...' -ForegroundColor Yellow
pip install -r requirements.txt --prefer-binary
Write-Host '[2/3] Installing Playwright browser...' -ForegroundColor Yellow
playwright install chromium
Write-Host ''
Write-Host 'Open: ..\frontend\odds_dashboard_v8.html' -ForegroundColor Cyan
Write-Host '[3/3] Starting backend...' -ForegroundColor Green
uvicorn app.main:app --reload --port 8000
