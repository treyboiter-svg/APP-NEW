"""odds_scraper.py — OverlineEdge v8 (Python 3.14 compatible)"""
import os, re
from datetime import datetime
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import pytz

BASE_URL  = "https://www.scoresandodds.com"
BET_TYPES = ["spread","total","moneyline"]
HEADLESS  = os.getenv("HEADLESS","1") != "0"
ET_TZ     = pytz.timezone("America/New_York")


def _clean_name(raw: str) -> str:
    s = (raw or "").strip()
    s = re.sub(r"\s*\d{1,2}(?:-\d{1,2}){0,2}-?\s*$","",s)
    s = re.sub(r"\s+\d+$","",s)
    return re.sub(r"\s+","",s).strip()


def is_today(time_str: str) -> bool:
    try:
        now = datetime.now(ET_TZ).date()
        s   = (time_str or "").strip().lower()
        if "today" in s: return True
        m = re.search(r"\b(\d{1,2})/(\d{1,2})\b",s)
        if m: return int(m.group(1))==now.month and int(m.group(2))==now.day
    except Exception:
        pass
    return False


def _click_market(page, bet_type):
    label = {"spread":"Spread","total":"Total","moneyline":"Moneyline"}[bet_type]
    for sel in [f"a:has-text('{label}')",f"button:has-text('{label}')",
                f"li:has-text('{label}')",f"[data-market='{bet_type}']"]:
        try:
            loc = page.locator(sel)
            if loc.count()>0:
                loc.first.click(timeout=1500)
                page.wait_for_timeout(300)
                return
        except Exception:
            continue


def parse_table(html, sport, bet_type):
    soup   = BeautifulSoup(html,"html.parser")
    prefix = f"odds-table-{bet_type}--"
    tbody  = soup.find("tbody",id=lambda x: x and prefix in x)
    if not tbody: return []
    games, cur = [], None
    for row in tbody.find_all("tr",recursive=False):
        tc = row.find("td",class_="game-time")
        if tc:
            if cur and cur["teams"]: games.append(cur)
            cur = {"sport":sport,"time":tc.get_text(strip=True),
                   "is_today":is_today(tc.get_text(strip=True)),"teams":[]}
        team_cell = row.find("td",class_="game-team")
        if team_cell and cur is not None:
            t = {}
            ns = team_cell.find("span",class_="team-name")
            if ns: t["name"] = _clean_name(ns.get_text(" ",strip=True))
            books = []
            for idx,cell in enumerate(row.find_all("td",class_="game-odds")):
                bk  = {"index":idx}
                val = cell.find("span",class_="data-value")
                ml  = cell.find("span",class_="data-moneyline")
                if val: bk["value"]     = val.get_text(strip=True)
                if ml:  bk["moneyline"] = ml.get_text(strip=True)
                if "value" in bk or "moneyline" in bk: books.append(bk)
            t["books"] = books
            cur["teams"].append(t)
    if cur and cur["teams"]: games.append(cur)
    return [g for g in games if g.get("is_today",False)]


def scrape_sport(sport: str):
    url     = f"{BASE_URL}/{sport.strip().lower()}/odds"
    results = {bt:[] for bt in BET_TYPES}
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS)
        page    = browser.new_context().new_page()
        try:
            page.goto(url,wait_until="domcontentloaded",timeout=60000)
            page.wait_for_timeout(1500)
            for bt in BET_TYPES:
                _click_market(page,bt)
                page.wait_for_timeout(400)
                results[bt] = parse_table(page.content(),sport,bt)
        except Exception as e:
            try:
                os.makedirs("data/debug_html",exist_ok=True)
                with open(f"data/debug_html/{sport}_error.html","w",encoding="utf-8") as f:
                    f.write(page.content())
            except Exception:
                pass
        finally:
            browser.close()
    count = max((len(results[bt]) for bt in BET_TYPES),default=0)
    return results, count
