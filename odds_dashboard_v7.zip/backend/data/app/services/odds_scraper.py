"""
odds_scraper.py — odds_dashboard_v7

Scrapes live bookmaker odds (spread, total, moneyline) from
scoresandodds.com for a given sport, for today's games only.

Output contract:
{
  "spread": [game, ...],
  "total": [game, ...],
  "moneyline": [game, ...],
}

Each game:
{
  "sport": "mlb",
  "time": "7/6 7:10PM",
  "is_today": True,
  "teams": [
    {"name": "Yankees", "books": [{"index": 0, "value": "-1.5", "moneyline": "+145", "raw_text": "-1.5 +145"}, ...]},
    {"name": "Rays", "books": [...]}
  ]
}
"""
from __future__ import annotations

import os
import re
from datetime import datetime

import pandas as pd
import pytz
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

BASE_URL = "https://www.scoresandodds.com"
SPORTS = ["nfl", "nba", "mlb", "ncaab", "ncaaf", "nhl"]
BET_TYPES = ["spread", "total", "moneyline"]

HEADLESS = os.getenv("HEADLESS", "1") != "0"
SLOW_MO_MS = int(os.getenv("SLOW_MO_MS", "0"))
ET_TZ = pytz.timezone("America/New_York")


def clean_team_name(raw: str) -> str:
    s = (raw or "").strip()
    s = s.replace("\xa0", " ")
    s = re.sub(r"\s*\d{1,2}(?:-\d{1,2}){0,2}-?\s*$", "", s)
    s = re.sub(r"\s+\(([RL])\)\s*$", "", s)
    s = re.sub(r"\s+([RL])\s*$", "", s)
    s = re.sub(r"[^\w\.\-\' ]+", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _clean_numeric_text(raw: str | None) -> str | None:
    if raw is None:
        return None
    s = str(raw).replace("−", "-").replace("＋", "+").strip()
    s = re.sub(r"\s+", " ", s)
    return s or None


def _to_float_or_none(raw):
    if raw is None:
        return None
    m = re.search(r"[-+]?\d+(?:\.\d+)?", str(raw))
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None


def _extract_moneyline(raw: str | None) -> str | None:
    s = _clean_numeric_text(raw)
    if not s:
        return None
    m = re.search(r"[+-]\d{2,4}", s)
    return m.group(0) if m else None


def _extract_point(raw: str | None) -> str | None:
    s = _clean_numeric_text(raw)
    if not s:
        return None
    m = re.search(r"[+-]?\d+(?:\.\d+)?", s)
    return m.group(0) if m else None


def is_today_game(game_time_str: str, assume_today_if_no_date: bool = False) -> bool:
    try:
        now_et = datetime.now(ET_TZ).date()
        s = (game_time_str or "").strip().lower()
        if "today" in s:
            return True
        m = re.search(r"\b(\d{1,2})/(\d{1,2})\b", s)
        if m:
            mm = int(m.group(1))
            dd = int(m.group(2))
            return (mm == now_et.month) and (dd == now_et.day)
        return assume_today_if_no_date
    except Exception:
        return False


def _best_effort_click_market(page, bet_type: str) -> None:
    label = {"spread": "Spread", "total": "Total", "moneyline": "Moneyline"}[bet_type]
    selectors = [
        f"role=tab[name='{label}']",
        f"button:has-text('{label}')",
        f"a:has-text('{label}')",
        f"li:has-text('{label}')",
        f"[data-market='{bet_type}']",
        f"[data-bet-type='{bet_type}']",
    ]

    for sel in selectors:
        try:
            loc = page.locator(sel)
            if loc.count() > 0:
                loc.first.click(timeout=1500)
                page.wait_for_timeout(300)
                return
        except Exception:
            continue
    print(f" [warn] no clickable selector found for market tab: {bet_type}")


def _find_market_tbodies(soup: BeautifulSoup, bet_type: str):
    wanted = f"odds-table-{bet_type}"
    tbodies = soup.find_all("tbody", id=lambda x: isinstance(x, str) and wanted in x)
    if tbodies:
        return tbodies

    # Fallback: some page variants may not preserve the exact id prefix.
    tbodies = []
    for tbody in soup.find_all("tbody"):
        rows = tbody.find_all("tr", recursive=False)
        if not rows:
            continue
        if any(row.find("td", class_=re.compile(r"game-team")) for row in rows):
            tbodies.append(tbody)
    return tbodies


def _parse_book_cell(cell, bet_type: str, idx: int) -> dict | None:
    raw_text = " ".join(s.strip() for s in cell.stripped_strings if s and s.strip())
    raw_text = _clean_numeric_text(raw_text)

    val_el = cell.find("span", class_=re.compile(r"data-value"))
    ml_el = cell.find("span", class_=re.compile(r"data-moneyline"))

    value = _clean_numeric_text(val_el.get_text(" ", strip=True)) if val_el else None
    moneyline = _clean_numeric_text(ml_el.get_text(" ", strip=True)) if ml_el else None

    if bet_type == "moneyline":
        if not moneyline:
            moneyline = _extract_moneyline(raw_text)
        if not value:
            value = moneyline or raw_text
    else:
        if not value:
            value = _extract_point(raw_text) or raw_text
        if not moneyline:
            moneyline = _extract_moneyline(raw_text)

    book = {"index": idx}
    if value:
        book["value"] = value
    if moneyline:
        book["moneyline"] = moneyline
    if raw_text:
        book["raw_text"] = raw_text

    return book if len(book) > 1 else None


def parse_odds_table(html: str, sport: str, bet_type: str):
    soup = BeautifulSoup(html, "html.parser")
    tbodies = _find_market_tbodies(soup, bet_type)

    if not tbodies:
        print(f" [warn] no tbody found for {sport}/{bet_type} — page may not have loaded this market tab")
        return []

    rows = []
    for tbody in tbodies:
        rows.extend(tbody.find_all("tr", recursive=False))

    games = []
    current_game = None

    for row in rows:
        time_cell = row.find("td", class_=re.compile(r"game-time"))
        if time_cell:
            if current_game and current_game["teams"]:
                games.append(current_game)
            time_txt = time_cell.get_text(" ", strip=True)
            current_game = {
                "sport": sport,
                "time": time_txt,
                "is_today": is_today_game(time_txt),
                "teams": [],
            }
            continue

        team_cell = row.find("td", class_=re.compile(r"game-team"))
        if not team_cell or not current_game:
            continue

        name_span = team_cell.find("span", class_=re.compile(r"team-name"))
        raw_name = name_span.get_text(" ", strip=True) if name_span else team_cell.get_text(" ", strip=True)
        team_name = clean_team_name(raw_name)
        if not team_name:
            continue

        odds_cells = row.find_all("td", class_=re.compile(r"game-odds"))
        books = []
        for idx, cell in enumerate(odds_cells):
            parsed = _parse_book_cell(cell, bet_type, idx)
            if parsed:
                books.append(parsed)

        team = {"name": team_name, "books": books}
        current_game["teams"].append(team)

    if current_game and current_game["teams"]:
        games.append(current_game)

    today_games = []
    for g in games:
        if not g.get("is_today", False):
            continue
        if len(g.get("teams", [])) < 2:
            continue
        today_games.append(g)

    return today_games


def scrape_sport(sport: str):
    sport = str(sport or "").strip().lower()
    url = f"{BASE_URL}/{sport}/odds"
    print(f"\n{sport.upper()} - Loading {url}")

    results = {bt: [] for bt in BET_TYPES}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS, slow_mo=SLOW_MO_MS)
        context = browser.new_context(
            viewport={"width": 1600, "height": 1200},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/126.0.0.0 Safari/537.36"
            ),
        )
        page = context.new_page()

        try:
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(1800)

            for bt in BET_TYPES:
                _best_effort_click_market(page, bt)
                page.wait_for_timeout(500)
                html = page.content()
                parsed = parse_odds_table(html, sport, bt)
                results[bt] = parsed

            # Fallback: if the clicked-tab parse failed for a market, retry
            # once against the final page HTML in case the site rendered a
            # single-table default view instead of switching tabs.
            final_html = page.content()
            for bt in BET_TYPES:
                if not results[bt]:
                    retry = parse_odds_table(final_html, sport, bt)
                    if retry:
                        results[bt] = retry

        except Exception as e:
            print(f" Error loading/parsing {sport}: {e}")
            try:
                os.makedirs("data/debug_html", exist_ok=True)
                with open(f"data/debug_html/{sport}_error.html", "w", encoding="utf-8") as fh:
                    fh.write(page.content())
                print(f" [debug] dumped raw page HTML to data/debug_html/{sport}_error.html")
            except Exception:
                pass
        finally:
            browser.close()

    count = max((len(results.get(bt, [])) for bt in BET_TYPES), default=0)
    if count == 0:
        print(f" [warn] 0 games found for {sport} — check data/debug_html/{sport}_error.html if it exists")
    else:
        print(f" Found {count} games for today")
    return results, count


def save_excel(sport_data, sport: str, output_dir: str):
    """
    Standalone export path — writes today's scraped odds to .xlsx.
    Independent of the dashboard pipeline; safe to run on its own.
    """
    if isinstance(sport_data, pd.DataFrame):
        df = sport_data.copy()
    elif isinstance(sport_data, list):
        df = pd.DataFrame(sport_data)
    else:
        spreads = dict(sport_data or {}).get("spread", [])
        totals = dict(sport_data or {}).get("total", [])
        mls = dict(sport_data or {}).get("moneyline", [])

        def key(game):
            if len(game.get("teams", [])) < 2:
                return None
            away = clean_team_name(game["teams"][0].get("name", ""))
            home = clean_team_name(game["teams"][1].get("name", ""))
            t = (game.get("time") or "").strip()
            return (t, away.lower(), home.lower())

        spread_map = {key(g): g for g in spreads if key(g)}
        total_map = {key(g): g for g in totals if key(g)}
        ml_map = {key(g): g for g in mls if key(g)}
        all_keys = set(spread_map.keys()) | set(total_map.keys()) | set(ml_map.keys())

        rows = []
        for k in sorted(all_keys):
            if not k:
                continue

            g_spread = spread_map.get(k)
            g_total = total_map.get(k)
            g_ml = ml_map.get(k)
            g_any = g_spread or g_total or g_ml

            if not g_any or len(g_any.get("teams", [])) < 2:
                continue

            away, home = g_any["teams"][0], g_any["teams"][1]
            t, _, _ = k

            row = {
                "Time": t,
                "Date": datetime.now(ET_TZ).strftime("%Y-%m-%d"),
                "Away_Team": away.get("name", ""),
                "Home_Team": home.get("name", ""),
                "Away_Spread": next((b.get("value", "") for b in (g_spread["teams"][0].get("books", []) if g_spread else []) if b.get("value")), ""),
                "Home_Spread": next((b.get("value", "") for b in (g_spread["teams"][1].get("books", []) if g_spread else []) if b.get("value")), ""),
            }

            if g_total and len(g_total.get("teams", [])) >= 2:
                away_tot_raw = next((b.get("value", "") for b in g_total["teams"][0].get("books", []) if b.get("value")), "")
                home_tot_raw = next((b.get("value", "") for b in g_total["teams"][1].get("books", []) if b.get("value")), "")
                tot_num = _to_float_or_none(away_tot_raw) or _to_float_or_none(home_tot_raw)
                row["Total"] = tot_num if tot_num is not None else (away_tot_raw or home_tot_raw or "")
                row["OU_Line"] = tot_num if tot_num is not None else ""
                row["over_odds"] = next((b.get("moneyline", "") for b in g_total["teams"][0].get("books", []) if b.get("moneyline")), "")
                row["under_odds"] = next((b.get("moneyline", "") for b in g_total["teams"][1].get("books", []) if b.get("moneyline")), "")
            else:
                row["Total"] = ""
                row["OU_Line"] = ""
                row["over_odds"] = ""
                row["under_odds"] = ""

            if g_ml and len(g_ml.get("teams", [])) >= 2:
                row["Away_ML"] = next((b.get("moneyline", "") for b in g_ml["teams"][0].get("books", []) if b.get("moneyline")), "")
                row["Home_ML"] = next((b.get("moneyline", "") for b in g_ml["teams"][1].get("books", []) if b.get("moneyline")), "")
            else:
                row["Away_ML"] = ""
                row["Home_ML"] = ""

            row["away_team"] = row["Away_Team"]
            row["home_team"] = row["Home_Team"]
            row["game_date"] = datetime.now(ET_TZ).strftime("%Y%m%d")
            row["league"] = str(sport or "").upper()

            rows.append(row)

        if not rows:
            return None

        df = pd.DataFrame(rows)

    ts = datetime.now(ET_TZ).strftime("%Y%m%d")
    os.makedirs(output_dir, exist_ok=True)
    filename = os.path.join(output_dir, f"Odds_{str(sport).upper()}_{ts}.xlsx")
    df.to_excel(filename, index=False)
    print(f" Saved: {filename}")
    return filename


def main():
    output_dir = "odds_data"
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 60)
    print("ODDS SCRAPER — odds_dashboard_v7")
    print("=" * 60)

    for sport in SPORTS:
        data, count = scrape_sport(sport)
        if count > 0:
            save_excel(data, sport, output_dir)
        else:
            print(f" No games/odds for {sport} today.")


if __name__ == "__main__":
    main()