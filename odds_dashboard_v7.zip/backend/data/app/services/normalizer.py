"""
normalizer.py — odds_dashboard_v7
Team name normalization, stable ID generation, and Kalshi/Polymarket
title matching.

Exports:
- strip_pitcher
- normalize_team
- team_id
- make_game_id
- game_date_et
- extract_teams_from_text
- match_teams
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime
from difflib import SequenceMatcher

import pytz

ET_TZ = pytz.timezone("America/New_York")

_MLB_TEAMS = [
    "White Sox", "Red Sox", "Blue Jays", "Diamondbacks", "Braves", "Orioles",
    "Cubs", "Reds", "Guardians", "Rockies", "Tigers", "Astros", "Royals",
    "Angels", "Dodgers", "Marlins", "Brewers", "Twins", "Mets", "Yankees",
    "Athletics", "Phillies", "Pirates", "Padres", "Giants", "Mariners",
    "Cardinals", "Rays", "Rangers", "Nationals",
]
_TEAM_PREFIXES = sorted([(t.lower(), t) for t in _MLB_TEAMS], key=lambda x: len(x[0]), reverse=True)


def _normalize_text(s: str) -> str:
    s = (s or "").strip().lower()
    s = s.replace("&", " and ")
    s = s.replace("st.", "st")
    s = re.sub(r"[^a-z0-9\s\-]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def strip_pitcher(raw: str) -> str:
    """
    MLB scraper rows often include the starting pitcher after the team name
    (e.g. 'Mets McLean'). Strip everything after the recognized MLB team name.
    """
    s = (raw or "").strip()
    sl = s.lower()
    for tl, tc in _TEAM_PREFIXES:
        if sl == tl:
            return tc
        if sl.startswith(tl + " "):
            return tc
    return s


_ALIASES: dict[str, str] = {
    # NFL
    "arizona cardinals": "Cardinals", "cardinals": "Cardinals",
    "atlanta falcons": "Falcons", "falcons": "Falcons",
    "baltimore ravens": "Ravens", "ravens": "Ravens",
    "buffalo bills": "Bills", "bills": "Bills",
    "carolina panthers": "Panthers", "panthers": "Panthers",
    "chicago bears": "Bears", "bears": "Bears",
    "cincinnati bengals": "Bengals", "bengals": "Bengals",
    "cleveland browns": "Browns", "browns": "Browns",
    "dallas cowboys": "Cowboys", "cowboys": "Cowboys",
    "denver broncos": "Broncos", "broncos": "Broncos",
    "detroit lions": "Lions", "lions": "Lions",
    "green bay packers": "Packers", "packers": "Packers",
    "houston texans": "Texans", "texans": "Texans",
    "indianapolis colts": "Colts", "colts": "Colts",
    "jacksonville jaguars": "Jaguars", "jaguars": "Jaguars",
    "kansas city chiefs": "Chiefs", "chiefs": "Chiefs",
    "las vegas raiders": "Raiders", "oakland raiders": "Raiders", "raiders": "Raiders",
    "los angeles chargers": "Chargers", "la chargers": "Chargers", "chargers": "Chargers",
    "los angeles rams": "Rams", "la rams": "Rams", "rams": "Rams",
    "miami dolphins": "Dolphins", "dolphins": "Dolphins",
    "minnesota vikings": "Vikings", "vikings": "Vikings",
    "new england patriots": "Patriots", "patriots": "Patriots",
    "new orleans saints": "Saints", "saints": "Saints",
    "new york giants": "Giants", "ny giants": "Giants", "nyg": "Giants",
    "new york jets": "Jets", "ny jets": "Jets", "nyj": "Jets",
    "philadelphia eagles": "Eagles", "eagles": "Eagles",
    "pittsburgh steelers": "Steelers", "steelers": "Steelers",
    "san francisco 49ers": "49ers", "sf 49ers": "49ers", "49ers": "49ers", "niners": "49ers",
    "seattle seahawks": "Seahawks", "seahawks": "Seahawks",
    "tampa bay buccaneers": "Buccaneers", "buccaneers": "Buccaneers", "bucs": "Buccaneers",
    "tennessee titans": "Titans", "titans": "Titans",
    "washington commanders": "Commanders", "commanders": "Commanders",

    # NBA
    "atlanta hawks": "Hawks", "hawks": "Hawks",
    "boston celtics": "Celtics", "celtics": "Celtics",
    "brooklyn nets": "Nets", "nets": "Nets",
    "charlotte hornets": "Hornets", "hornets": "Hornets",
    "chicago bulls": "Bulls", "bulls": "Bulls",
    "cleveland cavaliers": "Cavaliers", "cavaliers": "Cavaliers", "cavs": "Cavaliers",
    "dallas mavericks": "Mavericks", "mavericks": "Mavericks", "mavs": "Mavericks",
    "denver nuggets": "Nuggets", "nuggets": "Nuggets",
    "detroit pistons": "Pistons", "pistons": "Pistons",
    "golden state warriors": "Warriors", "warriors": "Warriors",
    "houston rockets": "Rockets", "rockets": "Rockets",
    "indiana pacers": "Pacers", "pacers": "Pacers",
    "los angeles clippers": "Clippers", "la clippers": "Clippers", "clippers": "Clippers",
    "los angeles lakers": "Lakers", "la lakers": "Lakers", "lakers": "Lakers",
    "memphis grizzlies": "Grizzlies", "grizzlies": "Grizzlies",
    "miami heat": "Heat", "heat": "Heat",
    "milwaukee bucks": "Bucks", "bucks": "Bucks",
    "minnesota timberwolves": "Timberwolves", "timberwolves": "Timberwolves", "wolves": "Timberwolves",
    "new orleans pelicans": "Pelicans", "pelicans": "Pelicans",
    "new york knicks": "Knicks", "knicks": "Knicks",
    "oklahoma city thunder": "Thunder", "thunder": "Thunder",
    "orlando magic": "Magic", "magic": "Magic",
    "philadelphia 76ers": "76ers", "76ers": "76ers", "sixers": "76ers",
    "phoenix suns": "Suns", "suns": "Suns",
    "portland trail blazers": "Trail Blazers", "trail blazers": "Trail Blazers", "blazers": "Trail Blazers",
    "sacramento kings": "Kings", "kings": "Kings",
    "san antonio spurs": "Spurs", "spurs": "Spurs",
    "toronto raptors": "Raptors", "raptors": "Raptors",
    "utah jazz": "Jazz", "jazz": "Jazz",
    "washington wizards": "Wizards", "wizards": "Wizards",

    # MLB
    "arizona diamondbacks": "Diamondbacks", "diamondbacks": "Diamondbacks", "d backs": "Diamondbacks", "d-backs": "Diamondbacks",
    "atlanta braves": "Braves", "braves": "Braves",
    "baltimore orioles": "Orioles", "orioles": "Orioles",
    "boston red sox": "Red Sox", "red sox": "Red Sox",
    "chicago cubs": "Cubs", "cubs": "Cubs",
    "chicago white sox": "White Sox", "white sox": "White Sox",
    "cincinnati reds": "Reds", "reds": "Reds",
    "cleveland guardians": "Guardians", "guardians": "Guardians",
    "colorado rockies": "Rockies", "rockies": "Rockies",
    "detroit tigers": "Tigers", "tigers": "Tigers",
    "houston astros": "Astros", "astros": "Astros",
    "kansas city royals": "Royals", "royals": "Royals",
    "los angeles angels": "Angels", "la angels": "Angels", "angels": "Angels",
    "los angeles dodgers": "Dodgers", "la dodgers": "Dodgers", "dodgers": "Dodgers",
    "miami marlins": "Marlins", "marlins": "Marlins",
    "milwaukee brewers": "Brewers", "brewers": "Brewers",
    "minnesota twins": "Twins", "twins": "Twins",
    "new york mets": "Mets", "mets": "Mets",
    "new york yankees": "Yankees", "yankees": "Yankees",
    "oakland athletics": "Athletics", "sacramento athletics": "Athletics", "athletics": "Athletics",
    "philadelphia phillies": "Phillies", "phillies": "Phillies",
    "pittsburgh pirates": "Pirates", "pirates": "Pirates",
    "san diego padres": "Padres", "padres": "Padres",
    "san francisco giants": "Giants", "sf giants": "Giants",
    "seattle mariners": "Mariners", "mariners": "Mariners",
    "st louis cardinals": "Cardinals", "st. louis cardinals": "Cardinals", "stl cardinals": "Cardinals",
    "tampa bay rays": "Rays", "rays": "Rays",
    "texas rangers": "Rangers",
    "toronto blue jays": "Blue Jays", "blue jays": "Blue Jays",
    "washington nationals": "Nationals", "nationals": "Nationals",

    # NHL
    "anaheim ducks": "Ducks", "ducks": "Ducks",
    "utah hockey club": "Utah HC", "utah hc": "Utah HC",
    "boston bruins": "Bruins", "bruins": "Bruins",
    "buffalo sabres": "Sabres", "sabres": "Sabres",
    "calgary flames": "Flames", "flames": "Flames",
    "carolina hurricanes": "Hurricanes", "hurricanes": "Hurricanes", "canes": "Hurricanes",
    "chicago blackhawks": "Blackhawks", "blackhawks": "Blackhawks",
    "colorado avalanche": "Avalanche", "avalanche": "Avalanche", "avs": "Avalanche",
    "columbus blue jackets": "Blue Jackets", "blue jackets": "Blue Jackets",
    "dallas stars": "Stars", "stars": "Stars",
    "detroit red wings": "Red Wings", "red wings": "Red Wings",
    "edmonton oilers": "Oilers", "oilers": "Oilers",
    "florida panthers": "Panthers",
    "vegas golden knights": "Golden Knights", "golden knights": "Golden Knights", "vgk": "Golden Knights",
    "los angeles kings": "Kings", "la kings": "Kings",
    "minnesota wild": "Wild", "wild": "Wild",
    "montreal canadiens": "Canadiens", "canadiens": "Canadiens", "habs": "Canadiens",
    "nashville predators": "Predators", "predators": "Predators", "preds": "Predators",
    "new jersey devils": "Devils", "devils": "Devils",
    "new york islanders": "Islanders", "islanders": "Islanders",
    "new york rangers": "Rangers", "ny rangers": "Rangers", "nyr": "Rangers",
    "ottawa senators": "Senators", "senators": "Senators", "sens": "Senators",
    "philadelphia flyers": "Flyers", "flyers": "Flyers",
    "pittsburgh penguins": "Penguins", "penguins": "Penguins", "pens": "Penguins",
    "san jose sharks": "Sharks", "sharks": "Sharks",
    "seattle kraken": "Kraken", "kraken": "Kraken",
    "st louis blues": "Blues", "st. louis blues": "Blues", "blues": "Blues",
    "tampa bay lightning": "Lightning", "lightning": "Lightning",
    "toronto maple leafs": "Maple Leafs", "maple leafs": "Maple Leafs", "leafs": "Maple Leafs",
    "vancouver canucks": "Canucks", "canucks": "Canucks",
    "washington capitals": "Capitals", "capitals": "Capitals", "caps": "Capitals",
    "winnipeg jets": "Jets",
}

# Unique canonical names only live here; overlapping nicknames are handled
# in _SPORT_OVERRIDES so team_id() is deterministic.
_TEAM_ID_MAP: dict[str, str] = {
    # NFL unique
    "Falcons": "nfl_falcons",
    "Ravens": "nfl_ravens",
    "Bills": "nfl_bills",
    "Bears": "nfl_bears",
    "Bengals": "nfl_bengals",
    "Browns": "nfl_browns",
    "Cowboys": "nfl_cowboys",
    "Broncos": "nfl_broncos",
    "Lions": "nfl_lions",
    "Packers": "nfl_packers",
    "Texans": "nfl_texans",
    "Colts": "nfl_colts",
    "Jaguars": "nfl_jaguars",
    "Chiefs": "nfl_chiefs",
    "Raiders": "nfl_raiders",
    "Chargers": "nfl_chargers",
    "Rams": "nfl_rams",
    "Dolphins": "nfl_dolphins",
    "Vikings": "nfl_vikings",
    "Patriots": "nfl_patriots",
    "Saints": "nfl_saints",
    "Eagles": "nfl_eagles",
    "Steelers": "nfl_steelers",
    "49ers": "nfl_49ers",
    "Seahawks": "nfl_seahawks",
    "Buccaneers": "nfl_buccaneers",
    "Titans": "nfl_titans",
    "Commanders": "nfl_commanders",

    # NBA unique
    "Hawks": "nba_hawks",
    "Celtics": "nba_celtics",
    "Nets": "nba_nets",
    "Hornets": "nba_hornets",
    "Cavaliers": "nba_cavaliers",
    "Mavericks": "nba_mavericks",
    "Nuggets": "nba_nuggets",
    "Pistons": "nba_pistons",
    "Warriors": "nba_warriors",
    "Rockets": "nba_rockets",
    "Pacers": "nba_pacers",
    "Clippers": "nba_clippers",
    "Lakers": "nba_lakers",
    "Grizzlies": "nba_grizzlies",
    "Heat": "nba_heat",
    "Bucks": "nba_bucks",
    "Timberwolves": "nba_timberwolves",
    "Pelicans": "nba_pelicans",
    "Knicks": "nba_knicks",
    "Thunder": "nba_thunder",
    "Magic": "nba_magic",
    "76ers": "nba_76ers",
    "Suns": "nba_suns",
    "Trail Blazers": "nba_trail_blazers",
    "Spurs": "nba_spurs",
    "Raptors": "nba_raptors",
    "Jazz": "nba_jazz",
    "Wizards": "nba_wizards",

    # MLB unique
    "Diamondbacks": "mlb_diamondbacks",
    "Braves": "mlb_braves",
    "Orioles": "mlb_orioles",
    "Red Sox": "mlb_red_sox",
    "Cubs": "mlb_cubs",
    "White Sox": "mlb_white_sox",
    "Reds": "mlb_reds",
    "Guardians": "mlb_guardians",
    "Rockies": "mlb_rockies",
    "Tigers": "mlb_tigers",
    "Astros": "mlb_astros",
    "Royals": "mlb_royals",
    "Angels": "mlb_angels",
    "Dodgers": "mlb_dodgers",
    "Marlins": "mlb_marlins",
    "Brewers": "mlb_brewers",
    "Twins": "mlb_twins",
    "Mets": "mlb_mets",
    "Yankees": "mlb_yankees",
    "Athletics": "mlb_athletics",
    "Phillies": "mlb_phillies",
    "Pirates": "mlb_pirates",
    "Padres": "mlb_padres",
    "Mariners": "mlb_mariners",
    "Rays": "mlb_rays",
    "Blue Jays": "mlb_blue_jays",
    "Nationals": "mlb_nationals",

    # NHL unique
    "Ducks": "nhl_ducks",
    "Utah HC": "nhl_utah_hc",
    "Bruins": "nhl_bruins",
    "Sabres": "nhl_sabres",
    "Flames": "nhl_flames",
    "Hurricanes": "nhl_hurricanes",
    "Blackhawks": "nhl_blackhawks",
    "Avalanche": "nhl_avalanche",
    "Blue Jackets": "nhl_blue_jackets",
    "Stars": "nhl_stars",
    "Red Wings": "nhl_red_wings",
    "Oilers": "nhl_oilers",
    "Golden Knights": "nhl_golden_knights",
    "Wild": "nhl_wild",
    "Canadiens": "nhl_canadiens",
    "Predators": "nhl_predators",
    "Devils": "nhl_devils",
    "Islanders": "nhl_islanders",
    "Senators": "nhl_senators",
    "Flyers": "nhl_flyers",
    "Penguins": "nhl_penguins",
    "Sharks": "nhl_sharks",
    "Kraken": "nhl_kraken",
    "Blues": "nhl_blues",
    "Lightning": "nhl_lightning",
    "Maple Leafs": "nhl_maple_leafs",
    "Canucks": "nhl_canucks",
    "Capitals": "nhl_capitals",
}

# Collision-safe overrides by sport.
_SPORT_OVERRIDES: dict[str, dict[str, str]] = {
    "mlb": {
        "Giants": "mlb_giants",
        "Cardinals": "mlb_cardinals",
        "Rangers": "mlb_rangers",
    },
    "nfl": {
        "Giants": "nfl_giants",
        "Cardinals": "nfl_cardinals",
        "Jets": "nfl_jets",
        "Panthers": "nfl_panthers",
    },
    "nhl": {
        "Panthers": "nhl_panthers",
        "Rangers": "nhl_rangers",
        "Kings": "nhl_kings",
        "Jets": "nhl_jets",
    },
    "nba": {
        "Kings": "nba_kings",
        "Bulls": "nba_bulls",
    },
    "ncaaf": {},
    "ncaab": {},
}

_ALL_CANONICAL = sorted(
    set(_TEAM_ID_MAP.keys()) |
    {name for mapping in _SPORT_OVERRIDES.values() for name in mapping.keys()},
    key=len,
    reverse=True,
)


def normalize_team(raw: str, sport: str = "") -> str:
    """
    Normalize a raw scraped team string to its canonical short name.
    """
    if not raw:
        return raw
    stripped = strip_pitcher(raw.strip())
    clean = _normalize_text(stripped)
    return _ALIASES.get(clean, stripped.strip())


def team_id(canonical: str, sport: str) -> str:
    sport_lc = (sport or "").lower()
    overrides = _SPORT_OVERRIDES.get(sport_lc, {})
    if canonical in overrides:
        return overrides[canonical]
    if canonical in _TEAM_ID_MAP:
        return _TEAM_ID_MAP[canonical]
    slug = re.sub(r"[^a-z0-9]+", "_", canonical.lower()).strip("_")
    return f"{sport_lc}_{slug}"


def make_game_id(sport: str, away_tid: str, home_tid: str, date_str: str) -> str:
    raw = f"{sport}|{away_tid}|{home_tid}|{date_str}"
    return hashlib.sha1(raw.encode()).hexdigest()[:12]


def game_date_et(time_str: str = "") -> str:
    return datetime.now(ET_TZ).strftime("%Y-%m-%d")


def extract_teams_from_text(text: str, sport: str = "") -> list[str]:
    """
    Extract canonical team names found inside a raw market title/question.
    Returns canonical names in textual order, longest-phrase-safe.
    """
    tl = _normalize_text(text)
    found: list[tuple[int, int, str]] = []

    for name in _ALL_CANONICAL:
        nl = _normalize_text(name)
        m = re.search(rf"(?<![a-z0-9]){re.escape(nl)}(?![a-z0-9])", tl)
        if m:
            found.append((m.start(), -len(nl), name))

    found.sort()
    ordered: list[str] = []
    seen = set()
    for _, _, name in found:
        if name not in seen:
            ordered.append(name)
            seen.add(name)
    return ordered


def match_teams(
    target_home: str,
    target_away: str,
    candidates: list[str],
    threshold: float = 0.6,
    sport: str = "",
) -> str | None:
    """
    Match a canonical (home, away) pair against candidate market strings.

    Strategy:
    1. Normalize full team names.
    2. Extract canonical team names from each candidate string.
    3. Prefer candidates containing both teams.
    4. Fall back to exact single-team key matches.
    5. Only then use fuzzy matching on the full normalized strings.
    """
    home = normalize_team(target_home, sport)
    away = normalize_team(target_away, sport)
    n_home = _normalize_text(home)
    n_away = _normalize_text(away)

    best_cand: str | None = None
    best_score = 0.0

    for cand in candidates:
        cl = _normalize_text(cand)
        extracted = [normalize_team(t, sport) for t in extract_teams_from_text(cand, sport)]
        extracted_norm = {_normalize_text(t) for t in extracted}

        score = 0.0

        if n_home in extracted_norm and n_away in extracted_norm:
            score = 1.0
        elif cl == n_home or cl == n_away:
            score = 0.97
        elif n_home in cl and n_away in cl:
            score = 0.93
        elif n_home in extracted_norm or n_away in extracted_norm:
            score = 0.78
        elif n_home in cl or n_away in cl:
            score = 0.70
        else:
            h_score = SequenceMatcher(None, n_home, cl).ratio()
            a_score = SequenceMatcher(None, n_away, cl).ratio()
            score = max(h_score, a_score)

        if score > best_score:
            best_score = score
            best_cand = cand

    return best_cand if best_score >= threshold else None