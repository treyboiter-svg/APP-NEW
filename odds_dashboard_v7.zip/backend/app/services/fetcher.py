"""
fetcher.py — odds_dashboard_v7
Assembles the full dashboard dict from three sources per sport:
  1. odds_scraper.py  -> real bookmaker moneyline/spread/total lines
  2. Kalshi            -> per-game prediction market (KX*GAME series only)
  3. Polymarket         -> per-game prediction market (series_id events only)

No futures/props/championship markets are included in either prediction
market source, by construction (correct series ticker / series_id
selection, not a keyword filter bolted on afterward).

Game ID architecture:
game_id = sha1(sport + away_team_id + home_team_id + date_ET)[:12]
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import re
from datetime import datetime

import httpx
import pytz

from app.core.config import KALSHI_BASE, KALSHI_SERIES, POLY_GAMMA, POLY_SERIES, SPORT_KEYS
from app.services.normalizer import normalize_team, team_id, match_teams
from app.services.odds_calc import american_to_implied, remove_vig, implied_to_american, build_implied_matrix
from app.services.odds_scraper import scrape_sport

logger = logging.getLogger(__name__)
ET_TZ = pytz.timezone("America/New_York")


# ── ID helpers ──────────────────────────────────────────────────────────

def make_game_id(sport: str, away_tid: str, home_tid: str, date_str: str) -> str:
    raw = f"{sport}|{away_tid}|{home_tid}|{date_str}"
    return hashlib.sha1(raw.encode()).hexdigest()[:12]


def _game_date_et(time_str: str) -> str:
    return datetime.now(ET_TZ).strftime("%Y-%m-%d")


# ── Bookmaker parsing helpers ────────────────────────────────────────────

def _parse_american(raw) -> int | None:
    if raw is None:
        return None
    m = re.search(r"[+-]?\d+", str(raw))
    return int(m.group(0)) if m else None


def _parse_point_american(raw) -> dict | None:
    if raw is None:
        return None
    s = str(raw)
    pts = re.search(r"[+-]?\d+(?:\.\d+)?", s)
    ml = re.search(r"[+-]\d{3,}", s)
    return {
        "point": float(pts.group(0)) if pts else None,
        "american": int(ml.group(0)) if ml else None,
    }


_BOOK_NAMES = [
    "draftkings", "fanduel", "betmgm", "caesars",
    "pointsbet", "bovada", "bet365", "betrivers",
    "superbook", "unibet",
]


def _build_book_map(scrape_results: dict) -> dict:
    """Merge spread/total/moneyline tables from the scraper into a
    per-game structure keyed by (away_canonical, home_canonical)."""
    merged: dict = {}

    for bt, games in scrape_results.items():
        for game in games:
            teams = game.get("teams", [])
            if len(teams) < 2:
                continue
            away_raw = teams[0].get("name", "")
            home_raw = teams[1].get("name", "")
            sport = game.get("sport", "")
            away = normalize_team(away_raw, sport)
            home = normalize_team(home_raw, sport)
            key = (away, home)
            if key not in merged:
                merged[key] = {"time": game.get("time", ""), "books": {}}

            for side_idx, team_obj in enumerate(teams):
                for bk in team_obj.get("books", []):
                    bidx = bk.get("index", 0)
                    if bidx not in merged[key]["books"]:
                        merged[key]["books"][bidx] = {}
                    entry = merged[key]["books"][bidx]
                    val = bk.get("value")
                    ml = bk.get("moneyline")
                    is_home = (side_idx == 1)

                    if bt == "moneyline":
                        if is_home:
                            entry["ml_home"] = _parse_american(ml or val)
                        else:
                            entry["ml_away"] = _parse_american(ml or val)
                    elif bt == "spread":
                        k = "spread_home" if is_home else "spread_away"
                        entry[k] = _parse_point_american(val)
                    elif bt == "total":
                        k = "total_over" if side_idx == 0 else "total_under"
                        entry[k] = _parse_point_american(val)

    return merged


def _aggregate_books(books_by_idx: dict) -> dict:
    """Return per-book dict + consensus implied probabilities.
    Logs a warning whenever a book's moneyline fails to parse, and
    whenever a game ends up with zero valid consensus data, instead of
    silently returning empty/None fields."""
    per_book = {}
    home_implieds, away_implieds = [], []

    for idx, bdata in books_by_idx.items():
        bname = _BOOK_NAMES[idx] if idx < len(_BOOK_NAMES) else f"book_{idx}"
        home_am = bdata.get("ml_home")
        away_am = bdata.get("ml_away")
        home_raw = american_to_implied(home_am)
        away_raw = american_to_implied(away_am)

        if home_raw is not None and away_raw is not None:
            home_nv, away_nv = remove_vig(home_raw, away_raw)
        else:
            home_nv, away_nv = home_raw, away_raw
            logger.warning(f"[{bname}] unparseable moneyline (home_am={home_am!r}, away_am={away_am!r}) — excluded from consensus")

        entry = {
            "home_american": home_am,
            "away_american": away_am,
            "home_raw": home_raw,
            "away_raw": away_raw,
            "home_nv": home_nv,
            "away_nv": away_nv,
            "spreads": {},
            "totals": {},
        }

        sh = bdata.get("spread_home")
        sa = bdata.get("spread_away")
        if sh:
            entry["spreads"]["home"] = {"point": sh.get("point"), "american": sh.get("american"),
                                         "implied": american_to_implied(sh.get("american"))}
        if sa:
            entry["spreads"]["away"] = {"point": sa.get("point"), "american": sa.get("american"),
                                         "implied": american_to_implied(sa.get("american"))}
        ov = bdata.get("total_over")
        un = bdata.get("total_under")
        if ov:
            entry["totals"]["Over"] = {"point": ov.get("point"), "american": ov.get("american"),
                                        "implied": american_to_implied(ov.get("american"))}
        if un:
            entry["totals"]["Under"] = {"point": un.get("point"), "american": un.get("american"),
                                         "implied": american_to_implied(un.get("american"))}

        per_book[bname] = entry
        if home_nv is not None:
            home_implieds.append(home_nv)
        if away_nv is not None:
            away_implieds.append(away_nv)

    if not home_implieds or not away_implieds:
        logger.warning("No valid moneylines parsed across any book for this game — consensus will be null")

    cons_home = round(sum(home_implieds) / len(home_implieds), 4) if home_implieds else None
    cons_away = round(sum(away_implieds) / len(away_implieds), 4) if away_implieds else None

    consensus = {
        "home": {
            "raw_implied": cons_home,
            "no_vig_implied": cons_home,
            "american": implied_to_american(cons_home) if cons_home else None,
        },
        "away": {
            "raw_implied": cons_away,
            "no_vig_implied": cons_away,
            "american": implied_to_american(cons_away) if cons_away else None,
        },
    }

    spread_agg: dict = {}
    totals_agg: dict = {}
    for bdata in per_book.values():
        for side, sdata in bdata.get("spreads", {}).items():
            spread_agg.setdefault(side, [])
            if sdata.get("implied"):
                spread_agg[side].append(sdata["implied"])
        for side, tdata in bdata.get("totals", {}).items():
            totals_agg.setdefault(side, [])
            if tdata.get("implied"):
                totals_agg[side].append(tdata["implied"])

    spread_cons = {s: {"implied": round(sum(v) / len(v), 4)} for s, v in spread_agg.items() if v}
    totals_cons = {s: {"implied": round(sum(v) / len(v), 4)} for s, v in totals_agg.items() if v}

    return per_book, consensus, spread_cons, totals_cons


# ── Kalshi (per-game series ONLY — see config.py KALSHI_SERIES) ────────

async def _fetch_kalshi(sport_label: str, client: httpx.AsyncClient) -> list[dict]:
    series_list = KALSHI_SERIES.get(sport_label, [])
    markets = []
    for series in series_list:
        try:
            r = await client.get(
                f"{KALSHI_BASE}/markets",
                params={"series_ticker": series, "status": "open", "limit": 200},
                timeout=15,
            )
            r.raise_for_status()
            markets.extend(r.json().get("markets", []))
        except Exception as e:
            logger.warning(f"Kalshi fetch error ({series}): {e}")
    if not markets:
        logger.warning(f"Kalshi returned 0 open markets for {sport_label} (series={series_list})")
    return markets


def _parse_kalshi(markets: list[dict], sport_label: str) -> dict:
    result = {}
    for m in markets:
        title = m.get("title") or m.get("subtitle") or ""
        yes_bid = m.get("yes_bid")
        yes_ask = m.get("yes_ask")
        volume = m.get("volume") or m.get("dollar_volume")
        if yes_bid is None and yes_ask is None:
            continue
        if yes_bid is not None and yes_ask is not None:
            mid = (yes_bid + yes_ask) / 2
        elif yes_bid is not None:
            mid = yes_bid
        else:
            mid = yes_ask
        implied = round(mid, 4) if mid else None
        result[title.lower()] = {
            "home_implied": implied,
            "american": implied_to_american(implied) if implied else None,
            "title": title,
            "volume": volume,
        }
    return result


# ── Polymarket (series_id via /events — per-game ONLY, not /markets?tag_id) ─

async def _fetch_polymarket(sport_label: str, client: httpx.AsyncClient) -> list[dict]:
    series_id = POLY_SERIES.get(sport_label)
    if series_id is None:
        return []
    try:
        r = await client.get(
            f"{POLY_GAMMA}/events",
            params={"series_id": series_id, "active": "true", "closed": "false", "limit": 200},
            timeout=15,
        )
        r.raise_for_status()
        payload = r.json()
        events = payload if isinstance(payload, list) else payload.get("events", [])
    except Exception as e:
        logger.warning(f"Polymarket fetch error ({sport_label}): {e}")
        return []

    markets = []
    for ev in events:
        markets.extend(ev.get("markets", []))
    if not markets:
        logger.warning(f"Polymarket returned 0 markets for {sport_label} (series_id={series_id})")
    return markets


def _parse_polymarket(markets: list[dict]) -> dict:
    result = {}
    for m in markets:
        question = m.get("question") or ""
        outcomes = m.get("outcomes") or []
        prices = m.get("outcomePrices") or []
        if len(outcomes) < 2 or len(prices) < 2:
            continue
        try:
            home_p = float(prices[0]) * 100
            away_p = float(prices[1]) * 100
        except Exception:
            continue
        result[question.lower()] = {
            "home_implied": round(home_p, 4),
            "away_implied": round(away_p, 4),
            "american": implied_to_american(home_p),
            "question": question,
        }
    return result


# ── Game assembly ────────────────────────────────────────────────────────

def _build_game(
    sport: str,
    away: str,
    home: str,
    time_str: str,
    per_book: dict,
    consensus: dict,
    spread: dict,
    totals: dict,
    kalshi_map: dict,
    poly_map: dict,
) -> dict:
    away_tid = team_id(away, sport)
    home_tid = team_id(home, sport)
    date_str = _game_date_et(time_str)
    gid = make_game_id(sport, away_tid, home_tid, date_str)

    title = f"{away} vs {home}"

    kalshi_entry: dict = {}
    k_candidates = list(kalshi_map.keys())
    k_match = match_teams(home, away, k_candidates, threshold=0.6, sport=sport)
    if k_match:
        kalshi_entry = kalshi_map[k_match]
    else:
        logger.info(f"No Kalshi match for {title}")

    poly_entry: dict = {}
    p_candidates = list(poly_map.keys())
    p_match = match_teams(home, away, p_candidates, threshold=0.6, sport=sport)
    if p_match:
        poly_entry = poly_map[p_match]
    else:
        logger.info(f"No Polymarket match for {title}")

    cons_home = (consensus.get("home") or {}).get("raw_implied")
    cons_away = (consensus.get("away") or {}).get("raw_implied")
    k_home_impl = kalshi_entry.get("home_implied")
    p_home_impl = poly_entry.get("home_implied")

    matrix_home = build_implied_matrix(cons_home, k_home_impl, p_home_impl)
    away_k_impl = (100 - k_home_impl) if k_home_impl is not None else None
    matrix_away = build_implied_matrix(cons_away, away_k_impl, poly_entry.get("away_implied"))

    return {
        "game_id": gid,
        "away_team_id": away_tid,
        "home_team_id": home_tid,
        "sport": sport,
        "title": title,
        "home": home,
        "away": away,
        "commence": time_str,
        "status": "scheduled",
        "per_book": per_book,
        "spread": spread,
        "totals": totals,
        "consensus": consensus,
        "kalshi": kalshi_entry or {"home_implied": None, "american": None, "title": None, "volume": None},
        "polymarket": poly_entry or {"home_implied": None, "away_implied": None, "american": None, "question": None},
        "implied_matrix_home": matrix_home,
        "implied_matrix_away": matrix_away,
    }


# ── Sport builder ─────────────────────────────────────────────────────────

async def build_sport(sport_label: str, sport_slug: str, client: httpx.AsyncClient) -> dict:
    loop = asyncio.get_event_loop()
    scrape_results, _ = await loop.run_in_executor(None, scrape_sport, sport_slug)

    book_map = _build_book_map(scrape_results)
    if not book_map:
        logger.warning(f"Scraper returned 0 games for {sport_slug} — no bookmaker odds available this cycle")

    kalshi_raw, poly_raw = await asyncio.gather(
        _fetch_kalshi(sport_label, client),
        _fetch_polymarket(sport_label, client),
    )
    kalshi_map = _parse_kalshi(kalshi_raw, sport_label)
    poly_map = _parse_polymarket(poly_raw)

    games = []
    for (away, home), gdata in book_map.items():
        per_book, consensus, spread, totals = _aggregate_books(gdata.get("books", {}))
        game = _build_game(
            sport=sport_slug,
            away=away,
            home=home,
            time_str=gdata.get("time", ""),
            per_book=per_book,
            consensus=consensus,
            spread=spread,
            totals=totals,
            kalshi_map=kalshi_map,
            poly_map=poly_map,
        )
        games.append(game)

    return {
        "games": games,
        "game_count": len(games),
        "last_updated": datetime.now().isoformat(),
    }


# ── Top-level ─────────────────────────────────────────────────────────────

async def build_all_sports() -> dict:
    dashboard = {}
    async with httpx.AsyncClient() as client:
        tasks = {
            label: build_sport(label, slug, client)
            for label, slug in SPORT_KEYS.items()
        }
        results = await asyncio.gather(*tasks.values(), return_exceptions=True)
        for label, result in zip(tasks.keys(), results):
            if isinstance(result, Exception):
                logger.error(f"build_sport failed for {label}: {result}", exc_info=result)
                dashboard[label] = {"games": [], "game_count": 0, "last_updated": datetime.now().isoformat()}
            else:
                dashboard[label] = result
    return dashboard
