"""
odds_calc.py — odds_dashboard_v7
Pure math helpers: American <-> implied probability, no-vig removal,
and the implied probability comparison matrix used per game.
"""
from __future__ import annotations


def american_to_implied(american) -> float | None:
    """Convert American odds to raw implied probability (0-100 scale)."""
    if american is None:
        return None
    try:
        a = float(american)
    except (TypeError, ValueError):
        return None
    if a == 0:
        return None
    if a > 0:
        prob = 100.0 / (a + 100.0)
    else:
        prob = (-a) / ((-a) + 100.0)
    return round(prob * 100.0, 4)


def implied_to_american(implied) -> int | None:
    """Convert implied probability (0-100 scale) back to American odds."""
    if implied is None:
        return None
    try:
        p = float(implied) / 100.0
    except (TypeError, ValueError):
        return None
    if p <= 0 or p >= 1:
        return None
    if p >= 0.5:
        odds = -100.0 * p / (1.0 - p)
    else:
        odds = 100.0 * (1.0 - p) / p
    return int(round(odds))


def remove_vig(home_implied: float, away_implied: float) -> tuple[float, float]:
    """
    Remove vig from a pair of raw implied probabilities (0-100 scale each)
    so they sum to 100. Standard proportional no-vig method.
    """
    if home_implied is None or away_implied is None:
        return home_implied, away_implied
    total = home_implied + away_implied
    if total <= 0:
        return home_implied, away_implied
    home_nv = round(home_implied / total * 100.0, 4)
    away_nv = round(away_implied / total * 100.0, 4)
    return home_nv, away_nv


def build_implied_matrix(consensus_implied, kalshi_implied, poly_implied, extra_implied=None) -> dict:
    """
    Build a simple comparison dict of implied probabilities across sources
    for one side (home or away) of a single game. No disparity/edge
    calculations here by design — this is a raw data matrix only.
    """
    return {
        "consensus": consensus_implied,
        "kalshi": kalshi_implied,
        "polymarket": poly_implied,
        "extra": extra_implied,
    }
