"""
routes.py — odds_dashboard_v7
FastAPI routes exposing the assembled dashboard.
"""
from fastapi import APIRouter, HTTPException

from app.services.fetcher import build_all_sports, build_sport
from app.core.config import SPORT_KEYS
import httpx

router = APIRouter()

_cache: dict = {}


@router.get("/api/dashboard")
async def get_dashboard():
    """Return the full multi-sport dashboard (all sports, all games)."""
    global _cache
    _cache = await build_all_sports()
    return _cache


@router.get("/api/dashboard/{sport_label}")
async def get_sport_dashboard(sport_label: str):
    """Return dashboard data for a single sport (mlb, nfl, nba, nhl, ncaaf, ncaab)."""
    sport_label = sport_label.lower()
    if sport_label not in SPORT_KEYS:
        raise HTTPException(status_code=404, detail=f"Unknown sport '{sport_label}'. Valid: {list(SPORT_KEYS.keys())}")
    async with httpx.AsyncClient() as client:
        result = await build_sport(sport_label, SPORT_KEYS[sport_label], client)
    return result


@router.get("/api/health")
async def health():
    return {"status": "ok"}
