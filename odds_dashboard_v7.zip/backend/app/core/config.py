"""
config.py — odds_dashboard_v7
All values below are confirmed live from Kalshi and Polymarket public
APIs/sites as of 2026-07-05. No placeholders, no futures tickers.
"""

KALSHI_BASE = "https://api.elections.kalshi.com/trade-api/v2"
POLY_GAMMA = "https://gamma-api.polymarket.com"

# sport_label -> scraper slug (must match odds_scraper.py SPORTS list)
SPORT_KEYS = {
    "mlb": "mlb",
    "nfl": "nfl",
    "nba": "nba",
    "nhl": "nhl",
    "ncaaf": "ncaaf",
    "ncaab": "ncaab",
}

# Kalshi per-game series tickers (confirmed live ticker prefixes).
# These are GAME markets only — NOT futures/win-total/championship series,
# which live under separate tickers (e.g. KXMLB, KXNFLWINS) and are
# intentionally excluded.
KALSHI_SERIES = {
    "mlb": ["KXMLBGAME"],
    "nfl": ["KXNFLGAME"],
    "nba": ["KXNBAGAME"],
    "nhl": ["KXNHLGAME"],
    "ncaaf": ["KXNCAAFGAME"],
    "ncaab": ["KXNCAABGAME"],
}

# Polymarket series_id values (confirmed live via gamma-api.polymarket.com/sports).
# Per-game events live under /events?series_id=..., NOT /markets?tag_id=...
# tag_id is a broad category shared by futures/props/games and must not be used.
POLY_SERIES = {
    "mlb": 3,
    "nfl": 10187,
    "nba": 10345,
    "nhl": 10346,
    "ncaaf": 10210,
    "ncaab": 39,
}

DB_PATH = "data/dashboard.db"
FETCH_INTERVAL_SECONDS = 120
