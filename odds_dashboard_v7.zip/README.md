# Odds Dashboard V7

Full rebuild — bookmaker odds (scoresandodds.com) merged with Kalshi and
Polymarket **single-game** prediction market odds (moneyline implied
probabilities), per sport, for MLB, NFL, NBA, NHL, NCAAF, NCAAB.

## What was fixed vs. prior versions

1. **Polymarket was pulling futures/props, not games.**
   Old code queried `/markets?tag_id=...`. Tags are broad categories shared
   by futures, props, AND games. Fixed to query `/events?series_id=...`,
   using confirmed live series IDs (see `app/core/config.py`), which
   returns per-game events only.

2. **Kalshi was pulling championship/win-total series, not games.**
   Fixed `KALSHI_SERIES` to use the confirmed per-game ticker prefixes
   (`KXMLBGAME`, `KXNFLGAME`, `KXNBAGAME`, `KXNHLGAME`, `KXNCAAFGAME`,
   `KXNCAABGAME`) instead of futures tickers (`KXMLB`, etc.).

3. **`match_teams()` was comparing only the last word of a team name**
   (e.g. "Sox", "Jays", "Knights") against the full candidate market
   string. Rewritten to extract the full canonical team name from each
   candidate and require identity match, eliminating false/missed matches.

4. **Silent failures replaced with logged warnings.** Any unparseable
   moneyline, empty scrape, or failed Kalshi/Polymarket match now logs a
   `logger.warning(...)` line instead of failing silently.

## Setup

```
cd backend
pip install -r requirements.txt
playwright install chromium
uvicorn app.main:app --reload --port 8000
```

## Endpoints

- `GET /api/dashboard` — all sports, all games
- `GET /api/dashboard/{sport}` — single sport (mlb, nfl, nba, nhl, ncaaf, ncaab)
- `GET /api/health` — health check

## Standalone scraper (Excel export)

The scraper also supports a standalone CLI mode that writes `.xlsx` files
per sport, independent of the FastAPI dashboard:

```
python -m app.services.odds_scraper
```

## Verified

- `normalize_team()` / `strip_pitcher()` tested against real scraped MLB
  rows (e.g. "Mets McLean" -> "Mets", id "mlb_mets").
- `remove_vig()` / `american_to_implied()` tested: -150/+125 moneyline pair
  correctly de-vigs to sum exactly 100.0 (57.4468 / 42.5532).
- `match_teams()` tested against realistic multi-word team names (Blue
  Jays, Nationals, Braves) inside full-sentence candidate strings —
  correctly matches all three test cases.

## Known unverified item

Live Kalshi/Polymarket API response shapes for the *specific* per-game
series above were confirmed via public site listings and Gamma sports
metadata, but a live end-to-end API pull against `/events?series_id=` and
`/markets?series_ticker=` was not completed in this session. Run the
service once against live data and check logs for
"returned 0 markets" warnings to confirm before relying on it in
production.
